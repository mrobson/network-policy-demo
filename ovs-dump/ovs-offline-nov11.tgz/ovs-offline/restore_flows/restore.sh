CURR_DIR=$(dirname $(realpath $0))
ln -s $CURR_DIR /tmp/ovs-save.Bak6ftAVdm
sh $CURR_DIR/do_restore.sh
