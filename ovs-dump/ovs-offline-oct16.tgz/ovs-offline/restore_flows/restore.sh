CURR_DIR=$(dirname $(realpath $0))
ln -s $CURR_DIR /tmp/ovs-save.y7x6S1TDQZ
sh $CURR_DIR/do_restore.sh
